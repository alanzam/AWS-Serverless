## Attribution

This photo is from [https://www.pexels.com/photo/red-hand-iphone-smartphone-80673/](https://www.pexels.com/photo/red-hand-iphone-smartphone-80673/) and is under the CC0 license. 