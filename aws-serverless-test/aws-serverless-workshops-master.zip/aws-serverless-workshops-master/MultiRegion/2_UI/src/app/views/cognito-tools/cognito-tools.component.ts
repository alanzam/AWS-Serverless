import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cognito-tools',
  templateUrl: './cognito-tools.component.html',
  styleUrls: ['./cognito-tools.component.css']
})
export class CognitoToolsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
