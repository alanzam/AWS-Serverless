export interface ITicket {
  id: number;
  description: string;
  assigned: string;
  priority: string;
  status: string;
  createdBy: string;
  createdOn: string;
}
